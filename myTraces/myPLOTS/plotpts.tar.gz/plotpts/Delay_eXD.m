


fXY_ran=importdata("plotsXY_random");
fXY_trans=importdata("plotsXY_transpose");

fDyAd_ran=importdata("plotsDyAD_Random");
fDyAd_trans=importdata("plotsDyAD_Transpose");

fNOP_ran=importdata("plotsNOP_Random");
fNOP_trans=importdata("plotsNOP_transpose");

fOE_ran=importdata("plotsOE_random");
fOE_trans=importdata("plotsOE_transpose");


xyRAN_pir=fXY_ran(:,1);
xyRAN_delay=fXY_ran(:,2);
xyRAN_ed=fXY_ran(:,4);

xyTRANS_pir=fXY_trans(:,1);
xyTRANS_delay=fXY_trans(:,2);
xyTRANS_ed=fXY_trans(:,4);


DyAdRAN_pir=fDyAd_ran(:,1);
DyAdRAN_delay=fDyAd_ran(:,2);
DyAdRAN_ed=fDyAd_ran(:,4);

DyAdTRANS_pir=fDyAd_trans(:,1);
DyAdTRANS_delay=fDyAd_trans(:,2);
DyAdTRANS_ed=fDyAd_trans(:,4);


oeRAN_pir=fOE_ran(:,1);
oeRAN_delay=fOE_ran(:,2);
oeRAN_ed=fOE_ran(:,4);

oeTRANS_pir=fOE_trans(:,1);
oeTRANS_delay=fOE_trans(:,2);
oeTRANS_ed=fOE_trans(:,4);


nopRAN_pir=fNOP_ran(:,1);
nopRAN_delay=fNOP_ran(:,2);
nopRAN_ed=fNOP_ran(:,4);

nopTRANS_pir=fNOP_trans(:,1);
nopTRANS_delay=fNOP_trans(:,2);
nopTRANS_ed=fNOP_trans(:,4);

plot(xyRAN_pir,xyRAN_delay);
hold;
plot(DyAdRAN_pir,DyAdRAN_delay);
hold;
plot(oeRAN_pir,oeRAN_delay);
hold;
plot(nopRAN_pir,nopRAN_delay);
hold;

